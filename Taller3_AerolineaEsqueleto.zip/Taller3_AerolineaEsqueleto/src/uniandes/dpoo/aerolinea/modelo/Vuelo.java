package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.tiquetes.*;

import uniandes.dpoo.aerolinea.modelo.tarifas.*;

public class Vuelo {
	private String fecha;
	public Ruta ruta;
	public Avion avion;
	public Map<String, Tiquete> tiquetes = new HashMap<String, Tiquete>();
	public boolean realizado; //Se agrega para tener constancia de si un vuelo ya se hizo o no sin perder su registro.
		
	public Vuelo(Ruta ruta, String fecha, Avion avion) {
		this.ruta = ruta;
		this.fecha = fecha;
		this.avion = avion;
	}
	public Ruta getRuta() {
		return ruta;
	}
	public String getFecha() {
		return fecha;
	}
	public Avion getAvion() {
		return avion;
	}
	public Collection<Tiquete> getTiquetes(){
		return tiquetes.values();
	}
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
    	int tarifa = calculadora.calcularTarifa(this, cliente);
    	return tarifa;
	}
	public boolean equals(Object object) {
		boolean retorno = true;
		if (this != object) {
			retorno = false;
		}
		if (object.getClass() != getClass()) {return false;}
		Vuelo vuelo = (Vuelo) object;
		return retorno && fecha.equals(vuelo.getFecha()) && avion.equals(vuelo.getAvion()) && ruta.equals(vuelo.getRuta());
	}
	public void marcarComoRealizado() {
		realizado = true;
	}
	public boolean getRealizado() {
		return realizado;
	}
}
