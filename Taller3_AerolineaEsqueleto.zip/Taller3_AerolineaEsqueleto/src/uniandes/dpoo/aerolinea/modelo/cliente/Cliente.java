package uniandes.dpoo.aerolinea.modelo.cliente;

import uniandes.dpoo.aerolinea.tiquetes.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.*;
public abstract class Cliente {

	public List<Tiquete> tiquetesSinUsar;
	public List<Tiquete> tiquetesUsados;
	
	public Cliente(){
		tiquetesSinUsar = new ArrayList<Tiquete>();
		tiquetesUsados = new ArrayList<Tiquete>();
		
	}
	
	
	public abstract String getTipoCliente();
	public abstract String getIdentificador();
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
	}
	public int calcularValorTotalTiquetes() {
		
		double total = 0;
		for (Tiquete tiqueteSin: tiquetesSinUsar) {
			total += tiqueteSin.getTarifa();
		}
		for (Tiquete tiqueteU: tiquetesUsados) {
			total += tiqueteU.getTarifa();
		}
		return (int) total;
		
	}
	public void usarTiquete(Vuelo vuelo) {
		Collection<Tiquete>tiquetesVuelo = vuelo.getTiquetes();
		for (Tiquete tiquete:tiquetesVuelo ) {
			if (tiquetesSinUsar.contains(tiquete)) {
				tiquetesSinUsar.remove(tiquete);
				tiquetesUsados.add(tiquete);
				tiquete.marcarComoUsado();
			}
		}
	}
}
