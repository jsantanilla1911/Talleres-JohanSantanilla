package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.Collection;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class ClienteNatural extends Cliente{

	
	public static String NATURAL = "Natural";
	private String Nombre;
	
	public ClienteNatural(String nombre) {
		
	}
	
	@Override
	public String getTipoCliente() {
		return NATURAL;
	}

	@Override
	public String getIdentificador() {
		return Nombre;
	}


	
	
}
