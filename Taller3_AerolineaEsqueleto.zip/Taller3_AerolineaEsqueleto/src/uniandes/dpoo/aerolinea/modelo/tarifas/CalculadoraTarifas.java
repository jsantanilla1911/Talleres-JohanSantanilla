package uniandes.dpoo.aerolinea.modelo.tarifas;
import uniandes.dpoo.aerolinea.modelo.cliente.*;
import uniandes.dpoo.aerolinea.modelo.*;
public abstract class CalculadoraTarifas {
	public static double IMPUESTO = 0.28;
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		int base = calcularCostoBase(vuelo, cliente);
		double descuento = calcularPorcentajeDescuento(cliente);
		int impuesto = calcularValorImpuestos(base);
		double tarifa = base - (base * descuento) + impuesto;
		return (int) tarifa;
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	protected int calcularDistanciaVuelo(Ruta ruta) {
		Aeropuerto destino = ruta.getDestino();
		Aeropuerto origen = ruta.getOrigen();
		return Aeropuerto.calcularDistancia(origen, destino);
	}
	protected int calcularValorImpuestos(int Base) {
		double retorno = Base * IMPUESTO;
		return (int)retorno;
	}
	
}
