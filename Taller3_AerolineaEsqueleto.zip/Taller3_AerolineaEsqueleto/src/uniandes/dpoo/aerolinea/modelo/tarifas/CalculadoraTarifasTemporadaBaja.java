package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas{

	
	protected int COSTO_POR_KM_NATURAL = 600;
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	protected double DESCUENTO_PEQ = 0.02;
	protected double DESCUENTO_MED = 0.1;
	protected double DESCUENTO_GR = 0.2;
	@Override
	public int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		int tarifa = 0;
		int distancia = calcularDistanciaVuelo(vuelo.getRuta());
		String tipo = cliente.getTipoCliente();
		if (tipo.equals("NATURAL")) {
			tarifa = COSTO_POR_KM_NATURAL * distancia;
		}
		else if(tipo.equals("CORPORATIVO")) {
			tarifa = COSTO_POR_KM_CORPORATIVO * distancia;
		}
		return tarifa;
	}

	@Override
	public double calcularPorcentajeDescuento(Cliente cliente) {
		String tipo = cliente.getTipoCliente();
		if(tipo.equals("CORPORATIVO")) {
			ClienteCorporativo cliC = (ClienteCorporativo) cliente;
			int tamaño = cliC.getTamañoEmpresa();
			if (tamaño == 1) {
				return DESCUENTO_GR;
			}
			else if (tamaño == 2) {
				return DESCUENTO_MED;
			}
			else if(tamaño ==3) {
				return DESCUENTO_PEQ;
			}
		}
		return 0;
	}

}
