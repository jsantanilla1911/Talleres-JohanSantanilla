package uniandes.dpoo.aerolinea.persistencia;

import java.io.IOException;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class PersistenciaAerolineaJson extends Object implements IPersistenciaAerolinea {

	
	/*Por tema de tiempos decidi no hacer la persistencia del taller, 
	 espero me comprendan y me disculpo de antemano*/
	
	
	public PersistenciaAerolineaJson() {
		super();
	}

	@Override
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws IOException, InformacionInconsistenteException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void salvarAerolinea(String archivo, Aerolinea areolinea) throws IOException {
		// TODO Auto-generated method stub
		
	}
	
}
